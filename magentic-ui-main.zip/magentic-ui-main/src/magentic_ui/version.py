VERSION = "0.0.4"
__version__ = VERSION
APP_NAME = "Magentic-UI"
