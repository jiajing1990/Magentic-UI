#!/usr/bin/env bash
set -e

umask 000

exec "$@"