export interface IStatus {
  message: string;
  status: boolean;
  data?: any;
}
