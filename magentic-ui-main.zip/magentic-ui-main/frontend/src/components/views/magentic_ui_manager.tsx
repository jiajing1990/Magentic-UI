import React from "react";

export const MagenticUIManager: React.FC = () => {
  return <div className="relative flex h-full w-full">Magentic-UI  component</div>;
};

export default MagenticUIManager;